<div class="qodef-reviews-list-info qodef-reviews-count">
	<<?php echo valeska_core_escape_title_tag( $title_tag ); ?> class="qodef-reviews-summary">
		<span class="qodef-reviews-number">
			<?php echo esc_html( $rating_number ); ?>
		</span>
		<span class="qodef-reviews-label">
			<?php echo esc_html( $rating_label ); ?>
		</span>
	</<?php echo valeska_core_escape_title_tag( $title_tag ); ?>>
</div>
