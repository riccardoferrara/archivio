<?php

class ValeskaCore_Accordion_Shortcode_Elementor extends ValeskaCore_Elementor_Widget_Base {

	function __construct( array $data = [], $args = null ) {
		$this->set_shortcode_slug( 'valeska_core_accordion' );

		parent::__construct( $data, $args );
	}
}

valeska_core_get_elementor_widgets_manager( new ValeskaCore_Accordion_Shortcode_Elementor() );
