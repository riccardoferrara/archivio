<?php

class ValeskaCore_Google_Map_Shortcode_Elementor extends ValeskaCore_Elementor_Widget_Base {

	function __construct( array $data = [], $args = null ) {
		$this->set_shortcode_slug( 'valeska_core_google_map' );

		parent::__construct( $data, $args );
	}
}

valeska_core_get_elementor_widgets_manager( new ValeskaCore_Google_Map_Shortcode_Elementor() );
